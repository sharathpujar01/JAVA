class BasicCalculator implements Calculator {
    
    int cells[];
    int t;
    
    private BasicCalculator() {
        cells = new int[2];
    }

    public Calculator clear() {
        //TODO - Add code here.
        //lls[]=0;
        cells[t]=0;
        t--;

            return this;	
    }

    public Calculator clearAll() {
        //TODO - Add code here.

       //ells[]=0;
        for (t=0;t<cells.length;t++ ) {
            cells[t]=0;
            
        }
        return this;	
    }

    public Calculator put(int n) {
        //TODO - Add code here.
        cells[t]=n;
        t++;

        return this;
    }

    public int read() {
        return cells[0];
    }

    public Calculator neg() {
        //TODO - Add code here.
        //this.x=x;
        cells[0]=-1*cells[0];
        return this;
    }

    public Calculator add() {
        //TODO - Add code here.
         //sum=x+y;
        cells[0]=cells[0]+cells[1];
        for(t=1;t<cells.length;t++)
        {
            cells[t]=0;
        }
        t=1;
        return this;
    }

    public Calculator sub() {
        //TODO - Add code here.
        cells[0]=cells[0]-cells[1];
        return this;
    }
    
    public Calculator mul() {
        //TODO - Add code here.
        cells[0]=cells[0]*cells[1];
        t=1;
        return this;
    }

    public Calculator div() {
        //TODO - Add code here.
        cells[0]=cells[0]/cells[1];
        t=1;
        return this;
    }

    public static Calculator getInstance() {
        Calculator calc = new BasicCalculator();
        calc.clearAll();

        return calc;
    }
}