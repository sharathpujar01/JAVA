import javax.swing.*;
import java.awt.*;
import java.awt.event.*;



public class ViewRecordUI extends JFrame implements ActionListener {

	JLabel lbl_bookID,lbl_bookname,lbl_bookPrice;
	JTextField txt_bookID,txt_bookname,txt_bookPrice;
	JButton but_first,but_previous,but_next,but_last;
	DBase db;



	ViewRecordUI(String title){

		super(title);

		Container contentPane = getContentPane();

		JPanel panel_center= new JPanel();
		panel_center.setLayout(new GridLayout(3,2, 50, 50));

		lbl_bookID = new JLabel("ID:");
		lbl_bookname = new JLabel("NAME:");
		lbl_bookPrice = new JLabel("PRICE:");

		txt_bookID = new JTextField();
		txt_bookname = new JTextField();
		txt_bookPrice = new JTextField();

		panel_center.add(lbl_bookID);
		panel_center.add(txt_bookID);
		panel_center.add(lbl_bookname);
		panel_center.add(txt_bookname);
		panel_center.add(lbl_bookPrice);
		panel_center.add(txt_bookPrice);




		JPanel panel_bottom = new JPanel();
		panel_bottom.setLayout(new GridLayout(1,4));

		but_first=new JButton("FIRST");
		but_first.addActionListener(this);
		but_previous =new JButton("PREVIOUS");
		but_previous.addActionListener(this);
		but_next=new JButton("NEXT");
		but_next.addActionListener(this);
		but_last=new JButton("LAST");
		but_last.addActionListener(this);

		panel_bottom.add(but_first);
		panel_bottom.add(but_previous);
		panel_bottom.add(but_next);
		panel_bottom.add(but_last);

		getConnection();



		contentPane.add(panel_center, BorderLayout.CENTER);
		contentPane.add(panel_bottom, BorderLayout.SOUTH);


		setSize(500, 500);
		setVisible(true);

	}

	public void getConnection(){
		db=new DBase();

		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/bookdb1";

		if(db.loadDriver(drivername)!=1){

			System.out.println("not able to load driver");
			return;
		}

		System.out.println("Successfully loaded driver.....");
		
		if(db.createConnection(databasename)!=1){

			System.out.println("not able to connect...");
			return;

		}

		System.out.println("Successfully connection establised.....");

		if(db.getStatement()!=1){

			System.out.println("not able to create statment object...");
			return;	
		}
		System.out.println("Successfully created statement object.....");

		db.retrieveRecord("Select * from bookinfo");
	}

	@Override

	public void actionPerformed(ActionEvent e){
		if(e.getSource()==but_first){
			try{
				if(db!=null){
							db.rs.first();
							txt_bookID.setText(String .valueOf((db.rs.getInt(1) + "\t")));
							txt_bookname.setText(db.rs.getString(2) + "\t");
							txt_bookPrice.setText(String.valueOf(db.rs.getDouble(3) + "\t"));
							//System.out.println();
						}
						else{
							JOptionPane.showMessageDialog(this,"No record found..");
						}
					}catch(Exception ex){
						System.out.println(ex);
					

					}
				}

					if(e.getSource()==but_previous){
						try{
							if(db!=null){
							
							if(db.rs.isFirst()){
								JOptionPane.showMessageDialog(this,"First record...");
							}
							else{
								db.rs.previous();
								txt_bookID.setText(String .valueOf((db.rs.getInt(1) + "\t")));
								txt_bookname.setText(db.rs.getString(2) + "\t");
								txt_bookPrice.setText(String.valueOf(db.rs.getDouble(3) + "\t"));
								//System.out.println();
							}
						}
					
							
						
					  }catch(Exception ex){
							System.out.println(ex);
						}
						
              		}


				if(e.getSource()==but_next){
					try{
						if(db!=null){
							
							if(db.rs.isLast()){
								JOptionPane.showMessageDialog(this,"Last record.....");
							}
							else{
								db.rs.next();
								txt_bookID.setText(String .valueOf((db.rs.getInt(1) + "\t")));
								txt_bookname.setText(db.rs.getString(2) + "\t");
								txt_bookPrice.setText(String.valueOf(db.rs.getDouble(3) + "\t"));
							}
							
						}

					}catch(Exception ex){
					System.out.println(ex);
					}
				}
				if(e.getSource()==but_last){

					try{
						if(db!=null){
							db.rs.last();
							    txt_bookID.setText(String .valueOf((db.rs.getInt(1) + "\t")));
								txt_bookname.setText(db.rs.getString(2) + "\t");
								txt_bookPrice.setText(String.valueOf(db.rs.getDouble(3) + "\t"));
						}
						else{
							JOptionPane.showMessageDialog(this,"No record found.....");
						}
					}catch(Exception ex){
						System.out.println(ex);
					}

				}

        }
	

	public static void main(String[] args) {
		new ViewRecordUI("RECORD");
	}

}