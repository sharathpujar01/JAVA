import java.util.Scanner;

public class ViewRecordConsole{

	public static void testEachRecords()throws Exception{  //static function

		DBase db = new DBase();

		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/bookdb1";

		if(db.loadDriver(drivername)!=1){

			System.out.println("not able to load driver");
			return;
		}

		System.out.println("Successfully loaded driver.....");
		
		if(db.createConnection(databasename)!=1){

			System.out.println("not able to connect...");
			return;

		}

		System.out.println("Successfully connection establised.....");

		if(db.getStatement()!=1){

			System.out.println("not able to create statment object...");
			return;	
		}
		System.out.println("Successfully created statement object.....");

		db.retrieveRecord("Select * from bookinfo");

		int choice = 0;

		Scanner sc = new Scanner(System.in);

		do{
			System.out.println(" ----------- Main Menu ----------------");
			System.out.println(" 1. First Record");
			System.out.println(" 2. Previous");
			System.out.println(" 3. Next ");
			System.out.println(" 4. Last");
			System.out.println(" 5. Exit");

			System.out.println(" Enter your choice");
			choice = sc.nextInt();

			switch(choice){
				case 1:
						if(db!=null){
							db.rs.first();
							System.out.print(db.rs.getInt(1) + "\t");
							System.out.print(db.rs.getString(2) + "\t");
							System.out.print(db.rs.getDouble(3) + "\t");
							System.out.println();
						}
						else{
							System.out.println("No record found.....");
						}
						break;
				case 2:
						if(db!=null){
							
							if(db.rs.isFirst()){
								System.out.println("First record.....");
							}
							else{
								db.rs.previous();
								System.out.print(db.rs.getInt(1) + "\t");
								System.out.print(db.rs.getString(2) + "\t");
								System.out.print(db.rs.getDouble(3) + "\t");
								System.out.println();
							}
							
						}
						
						break;
				case 3:
						if(db!=null){
							
							if(db.rs.isLast()){
								System.out.println("Last record.....");
							}
							else{
								db.rs.next();
								System.out.print(db.rs.getInt(1) + "\t");
								System.out.print(db.rs.getString(2) + "\t");
								System.out.print(db.rs.getDouble(3) + "\t");
								System.out.println();
							}
							
						}
						break;
				case 4:
						if(db!=null){
							db.rs.last();
							System.out.print(db.rs.getInt(1) + "\t");
							System.out.print(db.rs.getString(2) + "\t");
							System.out.print(db.rs.getDouble(3) + "\t");
							System.out.println();
						}
						else{
							System.out.println("No record found.....");
						}
						break;

			}

		}while(choice != 5);

		System.out.println("-------- End of application -----------");
		db.closeObject();

	}


	public static void main(String[] args) {
		
		try{
		
			testEachRecords();	
		
		}
		catch(Exception e){
		
			System.out.println(e);
		
		}
		
	}
}