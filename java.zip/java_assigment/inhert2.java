

class Shape{

	public String color;
	public boolean filled;

	Shape(){
		color = "red";
		filled = true;
	}

	Shape(String color, boolean filled){
		this.color = color;
		this.filled = filled;
	}	

	public String getColor(){
		return color;
	}

	public void setColor(String color){
		this.color = color;
	}
	public boolean isFilled(){
		return true;
	}
	public void setFilled(boolean filled){
		this.filled=true;
	}

	@Override
	public String toString(){
		return " color: " + color + " filled status: " + filled;
	}
}

class Circle extends Shape{

	private double radius;


	Circle(){
		radius = 1.0;
	}

	Circle(double radius){
		this.radius = radius;
	}

	Circle(String color, boolean filled, double radius){
		super(color, filled);
		this.radius = radius;
	}

	public double getRadius(){
		return radius;
	}

	public void setRadius(double radius){
		this.radius = radius;
	}
	public double getarea(){
		return 3.142*radius*radius;
	}
	public double getperimeter(){
		return 2*3.142*radius;
	}

		@Override
	public String toString(){

		return super.toString() + "radius: " + radius;
		
	}
}

class Rectangle extends Shape{
	private double width;
	private double length;

	Rectangle(){
		width=1.0;
		length=1.0;

	}
	Rectangle(double width,double length){
		this.width=width;
		this.length=length;
	}
	Rectangle(String color, boolean filled, double width,double length){
		super(color, filled);
		this.width = width;
		this.length =length;
	}
	public double getwidth(){
		return width;
	}

	public void setwidth(double width){
		this.width = width;
	}
	public double getlength(){
		return length;
	}

	public void setlength(double length){
		this.length = length;
	}
	public double getarea(){
		return width*length;
	}
	public double getperimeter(){
		return 2*(width+length);
	}


		@Override
	public String toString(){

		return super.toString() + "width: " + width  +"length:" +length;
		
	}


}

class Square extends Rectangle {

	//private double side;


	Square(){
		//sside = 1.0;
	}

	Square(double side){
		super(side,side);
	}

	Square(String color, boolean filled, double side){
		super(color, filled,side,side);
	//	this.side = side;
	}

	public double getside(){
		return getlength();
	}

	public void setlength(double length){
		//super(length);
		//this.side = side;
		super.setlength(length);
	}
	public void setwidth(double length){
		//super(width);
		//this.side = side;
		super.setwidth(length);
	}
	

	
		@Override
	public String toString(){

		return super.toString() + "side: " + getside();
		
	}
}





public class inhert2{

	public static void main(String[] args) {
		
		Circle c1 = new Circle("blue", true, 20.00);
		Rectangle r1=new Rectangle("white",true,40.00,40.00);
		Square s1=new Square("grey",true,20.00);

		c1.setColor("green");

		c1.setRadius(50.00);
		

		Circle c2 = new Circle(10.00);

		Circle c3 = new Circle();

		System.out.println(c1);
		System.out.println("area:"+c1.getarea());
		System.out.println("perimeter:"+c1.getperimeter());

		System.out.println(r1);
		System.out.println("area:"+r1.getarea());
		System.out.println("perimeter:"+r1.getperimeter());

		System.out.println(s1);


		// System.out.println(c2);

		// System.out.println(c3);


	}
}








