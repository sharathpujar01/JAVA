import java.util.Scanner;

public class TestBookShop{


	public static void testBookDB(){

		DBase db = new DBase();
		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/bookdb2";



		if(db.loadDriver(drivername)!=1){
			System.out.println("unable to load driver.....");
			return;

		}
		
		System.out.println("successfully loaded driver....");
		if(db.connectDB(databasename)!=1){

			System.out.println("unable to create connection.....");
			return;


		}
		System.out.println("successfully connected....");

		if(db.createDBStatement()!=1){

			System.out.println("unable to create statment.....");
			return;


		}
		System.out.println("successfully created statment....");


		db.retriveRecords("select * from bookdetail");
		try{

		while(db.rs.next()){
			System.out.println(" ");
			
			System.out.print(" "+ db.rs.getInt(1));
			System.out.print(" "+ db.rs.getString(2));
			System.out.print(" "+ db.rs.getFloat(3));
		}
		

	}catch(Exception e){

	}
	db.closeObjects();

		
	}
     
	
	public static void main(String[] args) {
	
		testBookDB();	
		
	}
}