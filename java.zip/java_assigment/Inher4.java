class Author{
	
	private String name;
	private String email;
	char gender;

	Author(String name,String email, char gender){

		this.name = name;
		this.email = email;
		this.gender = gender;
	}

	@Override
	public String toString(){
		return "author name:" + name + " email:" + email + " gender:" + gender;
	}

}

class Book{

	private String name;
	private Author author;
	private double price;
	private int qty = 0;

	Book(String name, Author author, double price){

		this.name = name;
		this.author = author;
		this.price = price;

	}
	Book(String name, Author author, double price,int qty){

		this.name = name;
		this.author = author;
		this.price = price;
		this.qty=qty;

	}
	public String getname(){
		return name;
	}
	public Author getauthor(){
		return author;
	}
	public double getPrice(){
		return price;
	}
	public void setPrice(double price){
		this.price = price;

	}
	public int getqty(){
		return qty;
	}
	public void setqty(){
		this.qty=qty;
	}

	@Override
	public String toString(){

		return "name " + name + " " + author + " price" + price +  "quantity" + qty ; 
	}
}



public class Inher4{
	
	public static void main(String[] args) {
		
		Author author = new Author("Sharath", "sharath@gmail.com", 'M');

		Book b = new Book("Java", author, 5000.00,2);

		System.out.println(b);

	}
}