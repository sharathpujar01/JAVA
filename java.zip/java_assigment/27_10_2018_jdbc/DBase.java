import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

class DBase{

	private Connection con;
	private Statement stm;

	ResultSet rs;

	public int loadDriver(String driver){

		try{

			Class.forName(driver);	
			return 1;
		}
		catch(Exception e){
			System.out.println(e);
			return -1;
		}
		
	}

	public int connectDB(String db){

		try{

			con = DriverManager.getConnection(db, "sharath", "sharath01");
			return 1;
		}
		catch(Exception e){
			System.out.println(e);
			return -1;
		}
		
	}

	public int createDBStatement(){

		try{

			stm = con.createStatement();
			return 1;
		}
		catch(Exception e){
			System.out.println(e);
			return -1;
		}
	}

	public int insertDBStatement(String sql){

		try{

			return stm.executeUpdate(sql);
		}
		catch(Exception e){
			System.out.println("Exception: "+ e);
			return -1;
		}
	}

	public int updateDBStatement(String sql){

		try{

			return stm.executeUpdate(sql);
		}
		catch(Exception e){
			System.out.println(e);
			return -1;
		}
	}

	public int deleteDBStatement(String sql){

		try{

			return stm.executeUpdate(sql);
		}
		catch(Exception e){
			System.out.println(e);
			return -1;
		}
	}


	public void retriveRecords(String sql){

		try{

			rs = stm.executeQuery(sql);
			
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

	public void closeObjects(){

		try{
			con.close();
			stm.close();
			rs.close();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}




