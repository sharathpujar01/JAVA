import java.util.Scanner;

public class TestBookShop{


	public static void testBookDB(){

		DBase db = new DBase();
		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/bookdb1";

		if(db.loadDriver(drivername)!=1){

			System.out.println("not able to load driver");
			return;
		}

		System.out.println("Successfully loaded driver.....");
		
		if(db.connectDB(databasename)!=1){

			System.out.println("not able to connect...");
			return;

		}

		System.out.println("Successfully connection establised.....");

		if(db.createDBStatement()!=1){

			System.out.println("not able to create statment object...");
			return;	
		}
		System.out.println("Successfully created statement object.....");

		db.retriveRecords("Select * from bookInfo");

		System.out.println("Successfully created result set object.....");

		try{

			while(db.rs.next()){

				System.out.println(db.rs.getInt(1));
				System.out.println(db.rs.getString(2));
				System.out.println(db.rs.getDouble(3));
			}		
		}catch(Exception e){

			System.out.println(e);
		}
		
		db.closeObjects();
		System.out.println("Successfully closed all objects.....");
	}


	public static int testAuthenticate(){

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter username and password");
		String username = sc.next();
		String password = sc.next();

		DBase db = new DBase();
		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/bookdb1";

		if(db.loadDriver(drivername)!=1){

			System.out.println("not able to load driver");
			return -1;
		}

		System.out.println("Successfully loaded driver.....");
		
		if(db.connectDB(databasename)!=1){

			System.out.println("not able to connect...");
			return -1;

		}

		System.out.println("Successfully connection establised.....");

		if(db.createDBStatement()!=1){

			System.out.println("not able to create statment object...");
			return -1;	
		}
		System.out.println("Successfully created statement object.....");

		db.retriveRecords("Select * from login");

		System.out.println("Successfully created result set object.....");

		boolean flag = false;
		try{

			while(db.rs.next()){

				if((username.equals(db.rs.getString(1))) && (password.equals(db.rs.getString(2)))){
					flag = true;
					return 1;
				}
				
			}		
		}catch(Exception e){

			System.out.println(e);
		}
		
		db.closeObjects();
		return -1;

	}

	//insert a record
	public static void testInsertBookDB(){

		Scanner sc = new Scanner(System.in);
		
		
		DBase db = new DBase();
		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/bookdb1";

		if(db.loadDriver(drivername)!=1){

			System.out.println("not able to load driver");
			return;
		}

		System.out.println("Successfully loaded driver.....");
		
		if(db.connectDB(databasename)!=1){

			System.out.println("not able to connect...");
			return;

		}

		System.out.println("Successfully connection establised.....");

		if(db.createDBStatement()!=1){

			System.out.println("not able to create statment object...");
			return;	
		}
		System.out.println("Successfully created statement object.....");

		System.out.println("Enter book id, name and price");
		int id = sc.nextInt();
		String bname = sc.next();
		double price = sc.nextDouble();

		String sql = "insert into bookinfo values(" + id + ",'" + bname + "'," + price +")";

		if(db.insertDBStatement(sql)!=1){

			System.out.println("not able to insert statment object...");
			return;	
		}

		db.closeObjects();
		
	}

	//delete a record
	public static void testDeleteBookDB(){
		Scanner sc = new Scanner(System.in);
		
		
		DBase db = new DBase();
		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/bookdb1";

		if(db.loadDriver(drivername)!=1){

			System.out.println("not able to load driver");
			return;
		}

		System.out.println("Successfully loaded driver.....");
		
		if(db.connectDB(databasename)!=1){

			System.out.println("not able to connect...");
			return;

		}

		System.out.println("Successfully connection establised.....");

		if(db.createDBStatement()!=1){

			System.out.println("not able to create statment object...");
			return;	
		}
		System.out.println("Successfully created statement object.....");

		System.out.println("Enter  id ");
		int id = sc.nextInt();
		//String bname = sc.next();
		//double price = sc.nextDouble();

		String sql = "Delete from bookinfo WHERE bookid="+id;

		if(db.deleteDBStatement(sql)!=1){

			System.out.println("not able to delete statment object...");
			return;	
		}

		db.closeObjects();
		
	}


				
	

	//update a record
	public static void testUpdateBookDB(){
		Scanner sc = new Scanner(System.in);
		
		
		DBase db = new DBase();
		String drivername = "com.mysql.jdbc.Driver";
		String databasename = "jdbc:mysql://localhost:3306/bookdb1";

		if(db.loadDriver(drivername)!=1){

			System.out.println("not able to load driver");
			return;
		}

		System.out.println("Successfully loaded driver.....");
		
		if(db.connectDB(databasename)!=1){

			System.out.println("not able to connect...");
			return;

		}

		System.out.println("Successfully connection establised.....");

		if(db.createDBStatement()!=1){

			System.out.println("not able to create statment object...");
			return;	
		}
		System.out.println("Successfully created statement object.....");

		System.out.println("Enter id,name,price ");
		int id = sc.nextInt();
		String bname = sc.next();
		double price = sc.nextDouble();

		String sql =" UPDATE bookinfo  SET bookname='"+bname+"',price = "+ price +" WHERE  bookid="+id ; 
		if(db.updateDBStatement(sql)!=1){

			System.out.println("not able to create statment object...");
			return;	
		}

		db.closeObjects();
		
	}

				
	
	public static void main(String[] args) {
		
		if(testAuthenticate()!= 1){
			System.out.println("Invalid user");
			return;
			
		}
		//testDeleteBookDB();
		//testInsertBookDB();
		testBookDB();	
		//testDeleteBookDB();
		//testBookDB();
		testUpdateBookDB();
		//testBookDB();
		
	}
}