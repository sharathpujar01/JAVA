import java.util.Scanner;
class cntstr
{
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the number of rows");
		int m=sc.nextInt();
		System.out.println("enter the number of columns");
		int n=sc.nextInt();
		int a[][] = new int[m][n];
		int b[][] = new int[m][n];
		int fmax;
		int fmin;
		System.out.println("enter the input matrix");
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		//System.out.println("Get the maximum and minimum value of an array");
		fmax = a[0][0];
		fmin = a[0][0];
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(fmax<a[i][j])
				{
					fmax = a[i][j];
				}
				if(fmin>a[i][j])
				{
					fmin = a[i][j];
				}
			}
		}

		System.out.println("Contrast Stretch");
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				b[i][j]=((a[i][j]-fmin)*255)/(fmax-fmin);//contrast stretch formula
			}
		}
		System.out.println("Obtained output");	
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
		System.out.print(b[i][j]+"\t");//output
		    }
		System.out.println();    
		}


	}
}