import java.util.Scanner;
class mask_mams{
	
	static Scanner sc=new Scanner(System.in);
	private static int mrow,mcol;
	private static int row,col;
	private static int p1[][] = new int[200][200];
	private static int p2[][] = new int[200][200];
	private static int m[][] = new int[100][100];

	public static void getInput()
	{
		System.out.println("Enter the dimension of the image, Row and columns:");
		row=sc.nextInt();
		col=sc.nextInt();
		System.out.println("Enter a "+row+" * "+col+"matrix");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				p1[i][j] = sc.nextInt();
			}
		}

		System.out.println("Enter the size of the mask:");
		mrow=sc.nextInt();
		mcol=mrow;
		System.out.println("Enter the mask values:");
		for(int i=0;i<mrow;i++)
		{
			for(int j=0;j<mcol;j++)
			{
				m[i][j] = sc.nextInt();

			}
		}

	}

	public static void lpf(int p1[][], int p2[][],int m[][],int width,int height, int maskSize)
	{ 
 
  		int w = width;   
  		int h = height;   
  		int max = 0, i=0, j=0;   
  		int start = maskSize/2;   
  		int size = maskSize*maskSize;   
  		int sum=0; 
		try
		{   
			for(i = start; i < h-start; i++)
			{    
				for(j = start; j < w-start; j++)
				{     
					sum=0; 

					for(int k = -1*start; k < (start+1); k++)
					{   

						for(int l = -1*start; l < (start+1); l++)
						{       //System.out.println("k = " + k + " l = " + l);  
							//System.out.println("inside"); 
							//System.out.println(m[k+start][l+start]);     
							sum += (p1[i+k][j+l])*(m[k+start][l+start]);     
						}     
					} 

					p2[i][j] = sum/size;    
   				} 
   			}

			for(i = 0; i < h; i++)
			{    
				for(j = 0; j < w; j++)
				{     
					if(i==0||j==0||i==h-1||j==w-1)
					{      
						p2[i][j] = p1[i][j]; 
					}
				}
			}

		}
		catch(Exception e)
		{
			System.out.println("E i = " + i + " j = " + j);
		}  
	} 
	
	public static void display(int p2[][],int row,int col)
	{
		System.out.println("Output After applying the mask:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(p2[i][j]+" ");
			}
			System.out.println();
		}
	}


	public static void main(String args[])
	{
		//Masking ob = new Masking();
		getInput();
		//maskOp();
		lpf(p1,p2,m,row,col,mrow);
		display(p2,row,col);
	}
}