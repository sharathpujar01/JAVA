 // class Dimension{
 // 	int dim;
 // 	Dimension(int dim){
 // 		this.dim=dim;
 // 	}
 // }
 class mask{
 public static void lpf(int p1[][], int p2[][],  int maskSize,int h,int w){ 
 	//Dimension dim=new Dimension();
 	//int w,h;
 
			// int w =this. width;  
	// int h = this.height;   
	int max = 0, i=0, j=0;   
	int start = maskSize/2;   
	int size = maskSize*maskSize;  
	int sum; 
 
 
  try{  
 for(i = start; i <  h-start; i++){   
 for(j = start; j < w-start; j++){    
 sum=0; 
 
    for(int k = -1*start; k < (start+1); k++){      
	for(int l = -1*start; l < (start+1); l++){       
	//System.out.println("k = " + k + " l = " + l);      
 sum += p1[i+k][j+l];     
 }  
   } 
 
    p2[i][j] = sum/size;   

 } 
  } 
 
  for(i = 0; i < h; i++)    
for(j = 0; j < w; j++)     
if(i==0||j==0||i==h-1||j==w-1)      
p2[i][j] = p1[i][j]; 
 
 }catch(Exception e){
System.out.println("E i = " + i + " j = " + j);
	}  
	}
public static void main(String[] args) {
	mask m=new mask();
}
}