import java.utill.Scanner;


class Histmain{
	public static void main(String[] args) {
		HistEqual hs=new HistEqual(System.in);
		System.out.println("".hs);
	}
}
