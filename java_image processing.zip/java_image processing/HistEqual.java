class HistEqual{
 	//public static void main(String[] args) {
	
	public static void histEq(int p1[][], int p2[][], int h,int w){ 
 
	// int w = width;   
	// int h = height;  
 	int prob[] = new int[256];  
 	float probTr[] = new float[256];  
 	float size = w * h; 
 
 	 for(int i = 0; i < h; i++)   
		 for(int j = 0; j < w; j++){     
					prob[p1[i][j]]++;    
		} 
 
 	 for(int i = 0; i < 256; i++)    
		for(int j = 0; j < i; j++){    
		 probTr[i] += (float)prob[j]/size; 
		}
 
 	 for(int i = 0; i < h; i++)   
 		for(int j = 0; j < w; j++){     
			p2[i][j] = ((int)(255 * probTr[p1[i][j]]));    
 				if(p2[i][j] > 255)  {    
					p2[i][j] = 255;  
 	 	} 
 
	 } 

 
 	}
 

  public static void main(String[] args) {
 	//HistEqual hist=new HistEqual();
 	histEq(p1,p2,h,w);
  }
}